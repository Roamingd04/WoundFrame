# Example naming

No example animal photographs are distributed with this repository.

The text file `example_file_names.txt` demonstrates supported naming patterns.

A simple mixed-folder dataset could look like:

```text
my_photos/
├── control01-Z0.jpg
├── control01-Z2.jpg
├── control01-Z5.jpg
├── control02-Z0.jpg
├── control02-Z2.jpg
├── control02-Z5.jpg
├── cap01-Z0.jpg
├── cap01-Z2.jpg
└── cap01-Z5.jpg
```

The script will automatically create rows for:

```text
control01
control02
cap01
```

and columns for:

```text
Z0
Z2
Z5
```
