# Suggested methods text

The following paragraph can be adapted for a manuscript. Replace bracketed details as appropriate.

> Serial wound photographs were standardized using a custom Python workflow (WoundFrame, version 1.0.0). Each image contained an in-frame metric reference positioned approximately in the wound plane. For each photograph, two points separated by a known physical distance on the reference and the wound center were manually selected. The image-specific pixel-to-millimeter ratio was calculated from the calibration segment. Images were then rotationally aligned to the calibration axis, resampled to a common spatial scale, and cropped to an identical physical field of view centered on the wound. The same processing parameters were applied to all images included in a given analysis. Calibration coordinates, processing parameters, software versions, and SHA-256 hashes of the source images were retained to support reproducibility. Original source photographs were preserved unchanged.

## If a scale bar is shown

Add:

> A scale bar generated from the standardized pixel-to-millimeter ratio was added to the processed images.

## If the panel is described separately

Possible figure-method wording:

> Standardized macroscopic images were arranged by subject and timepoint after physical-scale normalization; missing timepoints were left blank/marked as missing rather than imputed.

## Important reporting note

Do not state that the workflow corrects perspective distortion. It performs linear scale normalization using the in-frame reference. Accuracy therefore depends on the reference being approximately coplanar with the wound and on appropriate image acquisition geometry.
