# Usage guide

## 1. Install Python

Use Python 3.10 or newer.

Check:

```bash
python --version
```

On Windows, the Python launcher may instead be:

```bat
py --version
```

## 2. Install dependencies

From the repository folder:

```bash
python -m pip install -r requirements.txt
```

Windows alternative:

```bat
py -m pip install -r requirements.txt
```

Do not install `opencv-python-headless`. The calibration step requires OpenCV GUI windows.

## 3. Windows launcher

Double-click:

```text
run_windows.bat
```

For the default workflow, press **Enter** at:

```text
Use all defaults? [Y/n]:
```

This uses:

```text
Calibration distance : 20 mm
Crop                 : 20 x 20 mm
Scale bar            : 5 mm
Target resolution    : 50 px/mm
Fullscreen           : yes
Panel cell size      : 2.75 x 2.75 in
Panel spacing        : 0.25 horizontal / 0.40 vertical
```

Type `n` only when you want to customize values.

During customization, pressing **Enter** keeps the value shown in brackets.

## 4. Select the images

The program accepts:

- a folder;
- a ZIP archive.

The folder can be disorganized. Timepoints are detected from filenames or parent folder names.

## 5. Calibrate each new image

For each image:

1. click calibration point A;
2. click calibration point B at the exact distance selected in the launcher;
3. click the wound center;
4. press `Enter`.

Controls:

```text
Enter = accept
R     = reset this image
Esc   = skip this image
```

The click coordinates are saved after every accepted image. If the program is interrupted, already accepted images do not need to be repeated.

## 6. Re-run with different crop or layout settings

The calibration belongs to the dataset rather than to a particular figure layout.

Therefore, after the first calibration you may re-run with:

```text
Crop width = 25 mm
Crop height = 25 mm
Wspace = 0.35
Hspace = 0.50
```

without recalibrating the photographs.

## Direct command-line examples

### Interactive input selection

```bash
python woundframe.py
```

### Explicit folder

```bash
python woundframe.py --input "D:\study\photos"
```

### Explicit ZIP

```bash
python woundframe.py --input "D:\study\photos.zip"
```

### 25 x 25 mm crop

```bash
python woundframe.py \
  --input photos \
  --crop-width-mm 25 \
  --crop-height-mm 25
```

### Use a 10 mm ruler segment

```bash
python woundframe.py \
  --input photos \
  --calibration-mm 10
```

### Disable scale bar

```bash
python woundframe.py \
  --input photos \
  --scale-bar no
```

### Recalibrate from scratch

```bash
python woundframe.py \
  --input photos \
  --recalibrate
```

## Troubleshooting

### The calibration window does not open

Check that you installed:

```text
opencv-python
```

and not:

```text
opencv-python-headless
```

Try:

```bash
python -m pip uninstall opencv-python-headless
python -m pip install --upgrade opencv-python
```

### An image is missing from the panel

Check `unparsed_images.txt`.

The image probably does not contain a recognized timepoint token.

Rename, for example:

```text
rat01.jpg
```

to:

```text
rat01-Z2.jpg
```

### Images are too close together

Increase:

```text
Panel cell width
Panel cell height
Horizontal gap
Vertical gap
```

A useful spacious starting point is:

```text
Cell width  = 3.2
Cell height = 3.2
Wspace      = 0.35
Hspace      = 0.50
```

### The wrong image is used when duplicates exist

Open `duplicates.csv`.

For duplicate subject/timepoint combinations, the first image in deterministic filename order is used in the main panel. All crops are still retained.

### I changed the source images

The SHA-256 manifest changes and a new dataset directory is created. This prevents old calibration/output files from silently being applied to a changed dataset.
