# Outputs and reproducibility

The output structure deliberately separates source identity, manual calibration and processing settings.

## Dataset directory

Every source image is hashed using SHA-256.

A dataset identifier is derived from:

- the relative source-image path;
- the SHA-256 hash of the image bytes.

Example:

```text
wound_panel_output/
└── photos_a1b2c3d4e5f6/
```

Copying an unchanged dataset to another computer does not change the hashes.

Changing the contents of a source photograph changes the dataset identity.

## `input_manifest.csv`

Contains:

```text
relative_path
size_bytes
sha256
subject
timepoint
parsed
```

This file documents exactly which source files were used.

## `calibration.csv`

Stores the six manually selected coordinates for every calibrated image:

```text
x1
y1
x2
y2
cx
cy
```

where:

- `(x1, y1)` = ruler point A;
- `(x2, y2)` = ruler point B;
- `(cx, cy)` = wound center.

Coordinates are stored in the coordinate system of the original source image.

## Run directories

A separate run ID is calculated from the complete processing configuration.

Example:

```text
runs/
└── run_f45a8e9821/
```

Changing crop size, scale-bar settings, panel spacing or target resolution creates a different run ID.

## `settings.json`

Records:

- software version;
- dataset ID;
- every processing parameter.

This is the primary machine-readable configuration record.

## `processing_metadata.csv`

Records image-level processing values, including:

- calibration-segment length in pixels;
- original pixels/mm;
- rotation angle;
- resize factor;
- output crop filename.

## `environment_versions.txt`

Records:

- software version;
- Python version;
- operating system/platform;
- NumPy version;
- OpenCV version;
- Matplotlib version.

## `standardized_crops/`

Contains the individually standardized photographs used to construct the panel.

These files are useful for:

- manual quality control;
- assembling alternative figures;
- auditing the final panel;
- supplementary material.

## Panel files

Generated as:

```text
wound_panel_all_subjects.png
wound_panel_all_subjects.pdf
```

The PNG is written at 300 dpi.

The PDF preserves the figure layout in vector form while embedding the photographic panels as raster images.

## Duplicates

If more than one source file resolves to the same subject and timepoint:

- every standardized crop is saved;
- the first file in deterministic filename order is used in the main panel;
- the remaining files are reported in `duplicates.csv`.

## Unparsed files

If no timepoint can be inferred from a filename or its parent folders, the file is excluded from processing and listed in:

```text
unparsed_images.txt
```

## Suggested archival package for a manuscript

For long-term reproducibility, archive at least:

```text
raw source images
input_manifest.csv
calibration.csv
settings.json
processing_metadata.csv
environment_versions.txt
final panel PDF/PNG
software version / repository commit
```

If the source images cannot be publicly shared, the manifest, settings and code can still document the processing procedure, subject to local ethics/data-governance requirements.
