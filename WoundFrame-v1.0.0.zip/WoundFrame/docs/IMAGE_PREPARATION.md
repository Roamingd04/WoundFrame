# Image preparation and acquisition

Good standardization begins at image acquisition. The software can normalize image scale and crop size, but it cannot recover information lost through poor focus, severe perspective distortion or an incorrectly positioned ruler.

## Recommended acquisition setup

For every photograph:

- include an **in-frame metric ruler or other verified linear reference**;
- place the reference as close as practical to the **same geometric plane as the wound**;
- keep the camera sensor approximately parallel to the wound surface;
- keep the wound and calibration reference sharply focused;
- avoid strong shadows, glare and specular reflections;
- use consistent illumination across animals and timepoints;
- use consistent camera/lens settings when practical;
- avoid digital zoom;
- capture enough surrounding tissue to allow the desired physical crop;
- retain the original files unchanged.

A fixed camera stand is strongly recommended for prospective studies.

## Why the ruler should be coplanar

The script calculates pixels/mm from the two selected ruler points. If the ruler is closer to or farther from the camera than the wound, the ruler and wound are imaged at different magnifications.

Therefore:

> A ruler that is not approximately coplanar with the wound can produce a physically incorrect wound scale even when the software calculations are mathematically correct.

The script performs a 2D linear scale normalization. It does not perform 3D reconstruction or perspective correction.

## Choosing the calibration distance

Use the largest clearly identifiable distance that fits comfortably within the ruler in the image.

Examples:

- 10 mm: acceptable;
- 20 mm: usually preferable;
- 30 mm: useful if clearly visible and approximately coplanar.

For a 20 mm calibration:

```text
0 cm -> 2 cm
1 cm -> 3 cm
2 cm -> 4 cm
```

All are equivalent.

The two clicks do not need to start at zero.

## Naming photographs

Recommended format:

```text
<subject>-Z<day>.<extension>
```

Examples:

```text
control01-Z0.jpg
control01-Z2.jpg
control01-Z5.jpg
cap01-Z0.jpg
cap01-Z2.jpg
cap01-Z5.jpg
```

Accepted timepoint styles include:

```text
Z0
z2
Z10
Day4
day_4
day-4
D6
d_6
```

Avoid ambiguous subject identifiers that themselves look like timepoint tokens.

## Folder organization

### Option A: all images mixed together

This is fully supported:

```text
photos/
├── rat03-Z5.jpg
├── rat01-Z0.jpg
├── rat02-Z2.jpg
├── rat01-Z5.jpg
├── rat03-Z0.jpg
└── rat01-Z2.jpg
```

The file order does not matter.

### Option B: folders by timepoint

Also supported:

```text
photos/
├── Z0/
│   ├── rat01.jpg
│   ├── rat02.jpg
│   └── rat03.jpg
├── Z2/
│   ├── rat01.jpg
│   ├── rat02.jpg
│   └── rat03.jpg
└── Z5/
    ├── rat01.jpg
    ├── rat02.jpg
    └── rat03.jpg
```

### Option C: ZIP archive

The entire dataset may be supplied as a ZIP. Nested folders are allowed.

## Image formats

Supported:

```text
.jpg
.jpeg
.png
.tif
.tiff
.bmp
.webp
```

High-quality JPEG, PNG or TIFF are generally suitable.

## Brightness, contrast and color

For scientific figures:

- preserve the raw/original photographs;
- avoid selective editing of individual images;
- if a global brightness/contrast adjustment is required, apply the same documented procedure to all relevant images;
- do not alter the wound boundary;
- do not remove crust, exudate, ruler marks or other biologically/technically relevant features;
- do not use generative image editing on source data.

This tool itself does not modify brightness, contrast, saturation or color balance.
