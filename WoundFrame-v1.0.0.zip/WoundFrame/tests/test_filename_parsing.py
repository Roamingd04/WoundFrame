import sys
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT))

import woundframe as wps


class FilenameParsingTests(unittest.TestCase):
    def setUp(self):
        self.root = Path("/study")

    def test_standard_z_format(self):
        subject, day = wps.parse_subject_day(
            self.root / "rat01-Z0.jpg",
            self.root,
        )
        self.assertEqual(subject, "rat01")
        self.assertEqual(day, "z0")

    def test_multi_digit_timepoint(self):
        subject, day = wps.parse_subject_day(
            self.root / "rat01-Z10.jpg",
            self.root,
        )
        self.assertEqual(subject, "rat01")
        self.assertEqual(day, "z10")

    def test_day_format(self):
        subject, day = wps.parse_subject_day(
            self.root / "animal_03_day4.png",
            self.root,
        )
        self.assertEqual(subject, "animal-03")
        self.assertEqual(day, "z4")

    def test_d_format(self):
        subject, day = wps.parse_subject_day(
            self.root / "animal03-d6.jpg",
            self.root,
        )
        self.assertEqual(subject, "animal03")
        self.assertEqual(day, "z6")

    def test_timepoint_from_parent_folder(self):
        subject, day = wps.parse_subject_day(
            self.root / "Z5" / "rat01.jpg",
            self.root,
        )
        self.assertEqual(subject, "rat01")
        self.assertEqual(day, "z5")

    def test_existing_subject_with_d_letter(self):
        subject, day = wps.parse_subject_day(
            self.root / "capd-t1a-z2.jpg",
            self.root,
        )
        self.assertEqual(subject, "capd-t1a")
        self.assertEqual(day, "z2")

    def test_no_timepoint(self):
        subject, day = wps.parse_subject_day(
            self.root / "rat01.jpg",
            self.root,
        )
        self.assertIsNone(subject)
        self.assertIsNone(day)

    def test_numeric_timepoint_sort(self):
        days = ["z10", "z2", "z0", "z5"]
        result = sorted(days, key=wps.timepoint_number)
        self.assertEqual(result, ["z0", "z2", "z5", "z10"])


if __name__ == "__main__":
    unittest.main()
